<template>
  <h1>{{title}}</h1>
</template>

<script>
  export default {
    data() {
      return {
        title: 'Hello World'
      }
    }
  }
</script>
