# Vue Crash Course (TodoList)

This is the code for the crash course on YouTube

## Quick Start

```bash
# Install dependencies
npm install

# Serve on localhost:8080
npm run serve

# Build for production
npm run build
```
