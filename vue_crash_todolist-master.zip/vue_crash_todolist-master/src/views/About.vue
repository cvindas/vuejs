<template>
  <div class="about">
    <h1>About</h1>
    <p>This is the TodoList app v1.0.0. It is part of the Vue crash course on Youtube</p>
  </div>
</template>
