const mongoose = require('mongoose');
const {Schema} = mongoose;

localSchema = new Schema({
    title: {type: String, require: true},
    originCity: {type: String},
    endCity: {type: String},
    cantDays: {type: Number},
    price: {type: Number, require: true},
    image: {type: String}
});

module.exports = mongoose.model('local', localSchema);
