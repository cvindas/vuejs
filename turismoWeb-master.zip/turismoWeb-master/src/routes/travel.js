const express = require('express');
const router = express.Router();

travelCtrl = require('../controller/travelController');

router.get('/', travelCtrl.getTravels);
router.post("/", travelCtrl.createdTravel);
router.get('/:id', travelCtrl.getTravel);
router.put('/:id', travelCtrl.editTravel);
router.delete('/:id', travelCtrl.deleteTravel);

module.exports = router;
