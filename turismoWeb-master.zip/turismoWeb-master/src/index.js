const path = require('path');
const express = require('express');
const morgan = require('morgan');
const {mongoose} = require("./db-connect");

const app = express();
const travelRouter = require('./routes/travel.js');

const apiLo = '/api/travel'

// Settings

app.set('port', process.env.PORT || 3000);

// Middlewares

app.use(morgan('dev'));
app.use(express.json());

// Routes

app.use(apiLo, travelRouter);

// Public Routes

app.use(express.static(path.join(__dirname, 'public')));


// Listen

app.listen(app.get('port'),() => {
    console.log('Server on', app.get('port'))
});