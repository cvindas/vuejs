const Travel = require("./../models/travel");
const travelCtrl = {};

travelCtrl.getTravels = async(req,res,next)=>{
    var travels = await Travel.find();
    res.json(travels);
};

travelCtrl.createdTravel = async (req,res,next) =>{
    travel = new Travel ({
        title: req.body.title,
        originCity: req.body.originCity,
        endCity: req.body.endCity,
        cantDays: req.body.cantDays,
        price: req.body.price,
        image: req.body.image
    });
    await travel.save();
    res.json({
        status: "Travel Created! :D"
    });
}

travelCtrl.getTravel = async (req,res,next) => {
    var travel = await Travel.findById(req.params.id);
    res.json(travel);
};

travelCtrl.editTravel = async (req,res,next) => {
    travel = {
        title: req.body.title,
        originCity: req.body.originCity,
        endCity: req.body.endCity,
        cantDays: req.body.cantDays,
        price: req.body.price,
        image: req.body.image
    };
    await Travel.findByIdAndUpdate(req.params.id, {$set: travel}, {new: true});
    res.json({status: "Travel updated."});
}

travelCtrl.deleteTravel = async (req,res,next) => {
    await Travel.findByIdAndRemove(req.params.id);
    res.json({status: "Travel Deleted"});
}

module.exports = travelCtrl;