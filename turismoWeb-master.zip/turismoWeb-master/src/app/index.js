import Vue from 'vue';
import Navbar from './components/navbar.vue';
import Header from './components/header.vue';
import Travels from './components/travels.vue';
import VueResource from 'vue-resource';
import { join } from 'path';

Vue.use(VueResource);

new Vue({
    render: h => h(Navbar)
}).$mount('#navbar')

new Vue({
    render: h => h(Header)
}).$mount('#header')

new Vue({
    render: h => h(Travels)
}).$mount('#travels')