<template>
<div>
    <div v-for="travel of travels" class="card bg-dark text-white">
        <img class="card-img" :src="travel.image" alt="Card image">
            <div class="card-img-overlay">
                <h5 class="card-title">{{travel.title}}</h5>
                <p class="card-text">Origin city: {{travel.originCity}}</p>
                <p class="card-text">Price: {{travel.price}}</p>
        </div>
        <br><br><br><br>
    </div>
</div>
</template>

<script>
export default {    
    data(){
        return{
            travels: []
        }
    },
    created(){
        this.getTravels();
    },
    methods: {
        getTravels(){
            fetch('/api/travel')
            .then(res => res.json())
            .then(data => {
                this.travels = data;
                console.log(this.travels)
            });
        }
    }
}
</script>
