<template>
    <div>
                <nav class="navbar navbar-light bg-light">
                    <div class="container">
                        <h1 class="navbar-brand">ViajaCool</h1>
                    </div>
                </nav>
        </div>
</template>

