<template>
   <div>
        <div class="py-5">
        <header class="main-header">
            <div class="py-5">
                <div class="container justify-content-center align-items-center text-center">
                    <h1 class="display-1">ViajaCool</h1>
                    <h3 class="py-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore, quasi. Placeat esse obcaecati eligendi.</h3>
                    <button class="btn btn-info btn-lg">Conocer mas!.</button>
                </div>
            </div>
        </header>
    </div>
   </div>
</template>
