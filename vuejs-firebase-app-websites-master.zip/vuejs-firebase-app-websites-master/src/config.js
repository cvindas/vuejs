export default {
  apiKey: "AIzaSyCWXadRIwRAwLu9g5FiZiKFedzBSe3qFmI",
    authDomain: "vuejs-test-2470a.firebaseapp.com",
    databaseURL: "https://vuejs-test-2470a.firebaseio.com",
    projectId: "vuejs-test-2470a",
    storageBucket: "vuejs-test-2470a.appspot.com",
    messagingSenderId: "1090596409137"
}
